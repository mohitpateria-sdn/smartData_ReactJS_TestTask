import React, { Component } from 'react';
import './App.css';
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css';
import arrayMove from 'array-move';
import { SortableContainer, SortableElement } from 'react-sortable-hoc';


// Code for creating Image list 
const SortableItem = SortableElement(({ value }) =>
  <div className="col-xs-6 col-lg-3 col-md-4 col-lg-3 mt-3">
    <img className="image-item " src={value} />
  </div>
)

const SortableList = SortableContainer(({ items }) => {
  return (
    <div className="row">
      {items.map((value, index) => (
        <SortableItem key={`item-${value.id}`} index={index} value={value} />
      ))}
    </div>
  )
})
class SortableComponent extends Component {
  render() {
    return <div className="container-fluid">    
    <SortableList items={this.props.data} onSortEnd={this.props.onSortEnd} axis="xy" />;
    </div>
  }
}

class App extends React.Component {

  state = {
    items: ["https://image.shutterstock.com/z/stock-photo-mountains-during-sunset-beautiful-natural-landscape-in-the-summer-time-407021107.jpg", "https://image.shutterstock.com/z/stock-photo-traveler-look-at-the-ocean-and-rocks-travel-and-active-life-concept-adventure-and-travel-on-bali-1391242052.jpg", "https://image.shutterstock.com/z/stock-photo-wave-and-boat-on-the-beach-as-a-background-beautiful-natural-background-at-the-summer-time-from-air-1074395291.jpg", "https://image.shutterstock.com/z/stock-photo-tourist-on-the-peak-of-high-rocks-sport-and-active-life-concept-790930837.jpg", "https://s3-ap-southeast-2.amazonaws.com/images.getjarvis.com.au/9068b2bd089c037a144fc847b9967ee83dce0fe5299261a884adc3241a33604b.jpeg"]
  };
  onSortEnd = ({ oldIndex, newIndex }) => {
// Code For ConFirm Alert - on Yes : goTo applySort - on No : goto resetSort
    confirmAlert({
      title: 'Confirm to submit',
      message: 'Are you sure to do this.',
      buttons: [
        {
          label: 'Yes',
          onClick: () => this.applySort(oldIndex, newIndex)
        },
        {
          label: 'No',
          onClick: () => this.resetSort(oldIndex, newIndex)
        }
      ]
    });

  };

// Function for applying sort 
  applySort(oldIndex, newIndex) {
    this.setState(({ items }) => ({
      items: arrayMove(items, oldIndex, newIndex),
    }));
  }

  // Function for reseting  sort 
  resetSort() {
    this.setState(({ items }) => ({
      items: this.state.items,
    }));
  }
  render() {

    return (
      <div className="App">
        <div className="grid-list-container">
          <SortableComponent data={this.state.items} onSortEnd={this.onSortEnd} />
        </div>
      </div>
    )
  }
}

export default App;
